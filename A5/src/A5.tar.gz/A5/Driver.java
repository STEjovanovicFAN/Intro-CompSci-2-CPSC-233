
/*
 * Name: Stefan Jovanovic
 * Student ID #: 10135783
 * Version 7897589
 */


//import all the java sing stuff

public class Driver {
	
	public static void main(String[]args){
		//start
		MyFrame frame = new MyFrame();
		frame.setVisible(true);
	}

}
