/*
 * Name: Stefan Jovanovic
 * Student ID #: 10135783
 * Version 3
 */

/*
 * version 1: assignment is working, need to fix bugs 
 * version 2: fixed bugs and completed assignment 
 * version 3: added in coordinates to make less confusing
 * 
 * Note: the reason why I made version 3 is because on Jame Tams output.txt
 * he put in a 4(row) and 2(col) and it moved to my 5(row) and 3(col).
 * Also in the output.txt he said choose between 0-5? isnt that like saying
 * choose 1 coordinate out of 6 when you have 5? lol
 * 
 * Its like Friday no time to tell you guys about it 
 * also I'm lazy, wonder if you guys will read this lol.
 *   
 */
public class Driver {
	//starting point of program
	public static void main(String[]args){
		World createWorld = new World();
		createWorld.start();

	}

}
