/*
 * Name: Stefan Jovanovic
 * Student ID #: 10135783
 * Version 3
 */

public class Driver {
	//starts the program
	public static void main(String[]args){
		UserInterface newSession = new UserInterface();
		newSession.start();
		
	}
}
