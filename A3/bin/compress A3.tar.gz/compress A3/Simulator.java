/*
  Author:  James Tam
  Version: October 14, 2015

  Starting execution point for the program.

*/

/*
 * Name: Stefan Jovanovic
 * Student ID #: 10135783
 * version:5
 */
public class Simulator
{
    public static void main(String [] args)
    {
        World aWorld = new World();
        aWorld.start();
    }
}