/*
 * Name: Stefan Jovanovic
 * Student ID #: 10135783
 * Version: 1
 */

public class Driver {
	public static void main(String[]args){
		//start the program
		UserInterface start = new UserInterface();
		//quick introduction
		System.out.println("This program works by _____________");
		start.start();
	
	}
}
