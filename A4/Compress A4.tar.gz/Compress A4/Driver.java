/*
  Author:  James Tam
  Version: April 1, 2013

  Starting execution point.

*/


public class Driver
{
    public static void main(String [] args)
    {
        GameController startSimulation = new GameController();
        startSimulation.start();
        
    }
}